import React from 'react'
import { View, Text } from 'react-native'

const Connect = () => {
  return (
    <View 
     style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Connection</Text>
    </View>
  )
}

export default Connect
